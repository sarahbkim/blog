
$(document).ready(function() {
    $("#square").mouseenter(function() {
        $("#square-hover").show();
    }).mouseleave(function() {
        $("#square-hover").hide();
    });
});
